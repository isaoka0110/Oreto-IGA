/*  AutoGL $B!c$*<j7Z!d(B $B$N%5%s%W%k%W%m%0%i%`Nc(B */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

/* AutoGL $B!I$*$F$,$k!I$r;H$&$K$O(B,$B$3$N%X%C%@%U%!%$%k$r%$%s%/%k!<%I$9$k!#(B*/
#include <autogl.h>





/* $B%S%e!<>e$KI=<($5$l$k%b%G%k$rI=8=$9$k$?$a$NJQ?t72(B */

/* $BD>8r:9J,3J;R$K$h$k;0<!85%9%+%i!<>l(B */

/* $B3J;R$NBg$-$5!JH>J,!K(B */
#define HALF_GRID_SIZE 30.0

/* $B3J;R$NJ,3d?t(B */
#define CELLS 40

/* $B3J;R>e$N%9%+%i!<CM(B */
static double GridValues[CELLS + 1][CELLS + 1][CELLS + 1];

/* $B%3%s%?(B-$B$N:GBg!&:G>.CM(B */
static double MinRange = -1.0;
static double MaxRange = 5.0;

/* $B??$sCf$NEyCMLL$NCM(B */
static double LevelValue = 2.0;
/* $BI}!JB>$NFsKg$NEyCMLL$O!"(BLevelValue +- LevelWidth $B$H$J$k!#!K(B */
static double LevelWidth = 2.0;



/* $B;0<!85%9%+%i!<>l$NDj5A(B */
static double Function (double x, double y, double z)
{
  return sin (x * M_PI) + y * y + z * z;
}

/* $B;0<!853J;R$r=i4|2=$9$k!#(B */
static void InitializeGrid ()
{
  int i, j, k;

  /* $B%b%G%kMQJQ?t$r=i4|2=$9$k!#(B */
  for (i = 0; i <= CELLS; i++) {
    for (j = 0; j <= CELLS; j++) {
      for (k = 0; k <= CELLS; k++) {
	double scale = 4.0 / CELLS;
	
	GridValues[i][j][k] 
	  = Function ((i - CELLS / 2) * scale, 
		      (j - CELLS / 2) * scale,
		      (k - CELLS / 2) * scale);
      }
    }
  }
}

/* $B3J;RE@%$%s%G%C%/%9(B (gx,gy,gz) $B$N0LCV$rF@$k!#(B */
static void GetGridPointAt
(double points_OUT[3],
 int gx, int gy, int gz)
{
  double cellSize = HALF_GRID_SIZE * 2 / CELLS;
  
  points_OUT[0] = (gx - CELLS / 2) * cellSize;
  points_OUT[1] = (gy - CELLS / 2) * cellSize;
  points_OUT[2] = (gz - CELLS / 2) * cellSize;
}

/* $B3J;RE@%$%s%G%C%/%9(B (gx,gy,gz) $B$KBP1~$9$k%;%k$K$D$$$F!"(B*/
/* $B$=$N3FD:E@$N3J;RE@HV9f$rF@$k!#(B */
static void GetHexGridAt
(int hexGxs_OUT[8], int hexGys_OUT[8], int hexGzs_OUT[8],
 int gx, int gy, int gz) 
{
  hexGxs_OUT[0] = gx;
  hexGxs_OUT[1] = gx + 1;
  hexGxs_OUT[2] = gx + 1;
  hexGxs_OUT[3] = gx;
  hexGxs_OUT[4] = gx;
  hexGxs_OUT[5] = gx + 1;
  hexGxs_OUT[6] = gx + 1;
  hexGxs_OUT[7] = gx;
  
  hexGys_OUT[0] = gy;
  hexGys_OUT[1] = gy;
  hexGys_OUT[2] = gy + 1;
  hexGys_OUT[3] = gy + 1;
  hexGys_OUT[4] = gy;
  hexGys_OUT[5] = gy;
  hexGys_OUT[6] = gy + 1;
  hexGys_OUT[7] = gy + 1;
  
  hexGzs_OUT[0] = gz;
  hexGzs_OUT[1] = gz;
  hexGzs_OUT[2] = gz;
  hexGzs_OUT[3] = gz;
  hexGzs_OUT[4] = gz + 1;
  hexGzs_OUT[5] = gz + 1;
  hexGzs_OUT[6] = gz + 1;
  hexGzs_OUT[7] = gz + 1;
}

/* $B;MLLBN$NEyCMLL$rIA2h$9$k!#(B */
static void PlotTetraIsosurface
(int gxs[4], int gys[4], int gzs[4],
 double levelValue)
{
  int iVertex;
  double tetraPoints[4][3];
  double tetraValues[4];
  
  for (iVertex = 0; iVertex < 4; iVertex++) {
    int gx = gxs[iVertex];
    int gy = gys[iVertex];
    int gz = gzs[iVertex];

    GetGridPointAt (tetraPoints[iVertex],
		    gx, gy, gz);
    tetraValues[iVertex] = GridValues[gx][gy][gz];
  }

  /* $B;MLLBN$NEyCMLL$r%]%j%4%s$H$7$FIA2h$9$k!#(B */
  AutoGL_DrawTetrahedronIsosurface 
    (levelValue, tetraPoints, tetraValues);
  /* tetraPoints$B$O!"3FD:E@$G$N0LCV(B */
  /* tetraValues$B$O!"3FD:E@$G$N%9%+%i!<CM(B */
}

/* $BO;LLBN%;%k$NEyCMLL$rIA2h$9$k!#(B */
static void PlotHexIsosurface 
(int gxs[8], int gys[8], int gzs[8],
 double levelValue)
{
  int iTetra;
  
  /* $BO;LLBN%;%k$r;MLLBN#6$D$KJ,3d$9$k!#(B */
  for (iTetra = 0; iTetra < 6; iTetra++) {
    int tetraGxs[4], tetraGys[4], tetraGzs[4];
    int iVertex;
    
    for (iVertex = 0; iVertex < 4; iVertex++) {
      tetraGxs[iVertex] = gxs[AutoGL_HexToTetraMap[iTetra][iVertex]];
      tetraGys[iVertex] = gys[AutoGL_HexToTetraMap[iTetra][iVertex]];
      tetraGzs[iVertex] = gzs[AutoGL_HexToTetraMap[iTetra][iVertex]];
    }
    PlotTetraIsosurface (tetraGxs, tetraGys, tetraGzs, 
			 levelValue);
  }
}

/* $B3J;R$NEyCMLL$rIA2h$9$k!#(B */
static void PlotGridIsosurfaceOfLevel (double levelValue)
{
  double grade;
  double red, green, blue;
  int gx, gy, gz;

  /* 0.0 - 1.0 $B$N%0%l!<%ICM$KBP1~$9$k?'$rF@$k!#(B */
  grade = (levelValue - MinRange) / (MaxRange - MinRange);
  AutoGL_GetContourColor (&red, &green, &blue,
			  grade);
  AutoGL_SetColor (red, green, blue);

  /* $B3FO;LLBN%;%k$4$H$KIA2h$9$k!#(B */
  for (gx = 0; gx < CELLS; gx++) {
    for (gy = 0; gy < CELLS; gy++) {
      for (gz = 0; gz < CELLS; gz++) {
	int hexGxs[8], hexGys[8], hexGzs[8];

	GetHexGridAt (hexGxs, hexGys, hexGzs,
		      gx, gy, gz);
	PlotHexIsosurface (hexGxs, hexGys, hexGzs, 
			   levelValue);
      }
    }
  }
}

/* $BEyCMLL$rIA2h$9$k!#(B */
static void PlotIsosurface (void)
{
  /* $B;0Kg$NEyCMLL$rIA2h$9$k!#(B */
  PlotGridIsosurfaceOfLevel (LevelValue - LevelWidth);
  PlotGridIsosurfaceOfLevel (LevelValue);
  PlotGridIsosurfaceOfLevel (LevelValue + LevelWidth);
}



/* $B%S%e!<$N:FIA2h$N$?$a$N%3!<%k%P%C%/4X?t(B */
/* $B%S%e!<$,:FI=<($5$l$k$4$H$K8F$P$l$k!#(B */
static void RedrawView (void) 
{
  static int modelIsRendered = 0;

  /* $B2hLL:82<$K;0<!85:BI87O$rIA2h$9$k!#(B */
  AutoGL_DrawCoordinateSystem3D (20);

  /* $B3J;R$NOH$rIA2h$9$k!#(B */
  {
    double size = HALF_GRID_SIZE;

    AutoGL_SetColor (1, 1, 1);
    AutoGL_DrawBox3D (-size, -size, -size,
		      size, size, size);
  }

  /* $BH>F)L@I=<($rM-8z$K$9$k!#(B */
  AutoGL_TurnOnTransparency ();

  /* $B$^$:!"0lEY$@$1%b%G%k$r%G%#%9%W%l%$%j%9%H$XIA2h$7$F$*$/!#(B */
  if (!modelIsRendered) {

    /* $B%G%#%9%W%l%$%j%9%H$r3+$-!"$3$l$r6u$K$9$k!#(B */
    AutoGL_OpenDisplayList ();

    PlotIsosurface ();

    /* $B%G%#%9%W%l%$%j%9%H$rJD$8$k!#(B */
    AutoGL_CloseDisplayList ();

    modelIsRendered = 1;
  }

  /* $B%G%#%9%W%l%$%j%9%H$KF~$l$?IA2hL?Na$r<B:]$KIA2h$9$k!#(B */
  AutoGL_DrawDisplayList ();
}

/* $B4X?t(BAutoGL_SetUp$B$O%f!<%6!<B&%W%m%0%i%`$4$H$KI,$:0l$DMQ0U$9$k$3$H!#(B*/
/* $B$3$3$G!"%3!<%k%P%C%/4X?t$d@)8fJQ?t$J$I$rEPO?$9$k!#(B*/
void AutoGL_SetUp (int argc, char *argv[]) 
{
  InitializeGrid ();

  AutoGL_SetViewSize (60);   /* $B%S%e!<$N%5%$%:(B */

  /* $B$*$^$8$J$$(B */
  AutoGL_SetViewRedrawCallback (RedrawView);    
  AutoGL_SetMode3D (AUTOGL_MODE_3D_ROTATE_XY); /* $B%^%&%9$G2sE>(B */
  AutoGL_SetDefaultCallbackInMode3D (NULL);

#if 0
  /* $B$b$7IA2h$,=E$1$l$P%I%i%C%0Cf$OIA2h$5$;$J$$$[$&$,$h$$!#(B */
  AutoGL_EnableDragInMode3D ();
#endif
}


