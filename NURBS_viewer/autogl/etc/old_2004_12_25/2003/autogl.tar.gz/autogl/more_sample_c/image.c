/*  AutoGL $B!c$*<j7Z!d(B $B$N%5%s%W%k%W%m%0%i%`Nc(B */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

/* AutoGL $B!I$*$F$,$k!I$r;H$&$K$O(B,$B$3$N%X%C%@%U%!%$%k$r%$%s%/%k!<%I$9$k!#(B*/
#include <autogl.h>

/* $B%f!<%F%#%j%F%#$N%$%a!<%8%G!<%?$NI=<((B */
/* $B0z?t$J$I>\$7$$>pJs$O(B, autogl_utility.h$B$r;2>H!#(B*/
/* $B$J$*!"$3$l$O(Bautogl.h$B$+$i(Binclude$B$5$l$F$$$k!#(B*/



int imageWidth0, imageHeight0;
unsigned char *imageData0;

int imageWidth1, imageHeight1;
unsigned char *imageData1;

static void ReadImages ()
{
  AutoGL_ReadImageFromPPMFile 
    ("../images/half.ppm",
     &imageWidth0, &imageHeight0, &imageData0);

  AutoGL_ReadImageFromPPMFile 
    ("../images/quarter.ppm",
     &imageWidth1, &imageHeight1, &imageData1);
}



/* $B%3!<%k%P%C%/4X?t72(B */

/* $B%S%e!<$N:FIA2h$N$?$a$N%3!<%k%P%C%/4X?t(B */
/* $B%S%e!<$,:FI=<($5$l$k$4$H$K8F$P$l$k!#(B */
static void RedrawView (void) 
{
  AutoGL_SetColor (1, 1, 1);
  AutoGL_DrawString (0, 0, 0, "O");
  AutoGL_DrawLine (0, 0, 0,
		   50, 0, 0);
  AutoGL_DrawString (50, 0, 0, "X");  
  AutoGL_DrawLine (0, 0, 0,
		   0, 50, 0);
  AutoGL_DrawString (0, 50, 0, "Y");  
  AutoGL_DrawLine (0, 0, 0,
		   0, 0, 50);
  AutoGL_DrawString (0, 0, 50, "Z");  

  AutoGL_DrawImage (30, 30, 30,
		    imageWidth0, imageHeight0, imageData0);

  AutoGL_DrawImage (30, 0, 0,
		    imageWidth1, imageHeight1, imageData1);
  AutoGL_DrawImage (0, 30, 0,
		    imageWidth1, imageHeight1, imageData1);
  AutoGL_DrawImage (0, 0, 30,
		    imageWidth1, imageHeight1, imageData1);
  
}



/* $B4X?t(BAutoGL_SetUp$B$O%f!<%6!<B&%W%m%0%i%`$4$H$KI,$:0l$DMQ0U$9$k$3$H!#(B*/
/* $B$3$3$G!"%3!<%k%P%C%/4X?t$d@)8fJQ?t$J$I$rEPO?$9$k!#(B*/
void AutoGL_SetUp (int argc, char *argv[]) 
{
  /* $B%S%e!<$N$_$N9=@.Nc(B */

  /* $B%S%e!<%$%s%0%Q%i%a!<%?!J%5%$%:(B,$B;k@~J}8~$J$I!K$r@_Dj$9$k!#(B*/
  AutoGL_SetViewSize (70);                 /* $B%S%e!<$NBg$-$5(B */
  AutoGL_SetViewCenter (10, 10, 10);       /* $BCm;kE@(B */
  AutoGL_SetViewDirection (1, 2, 3);       /* $B;k@~J}8~(B */

  /* $BF);kEj1F%b!<%I$K$9$k!#(B*/
  AutoGL_SetPerspectiveViewFlag (1);

  AutoGL_SetViewRedrawCallback (RedrawView); 
  /* $B:FIA2h%3!<%k%P%C%/4X?t$H$7$F>e$K$"$k(BRedrawView ()$B$r;XDj!#(B */
  
  /* $B$*$^$8$J$$(B */
  AutoGL_SetMode3D (AUTOGL_MODE_3D_ROTATE_XY); /* $B%^%&%9$G2sE>(B */
  AutoGL_SetDefaultCallbackInMode3D (NULL);
  AutoGL_EnableDragInMode3D ();                /* $B%I%i%C%0M-8z(B */

  ReadImages ();
}






