/* autogl_fortran.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "autogl.h"



extern int main (int argc, char *argv[]);

extern void autoglsetup_ (void);
extern void autoglredraw_ (void);

#define MAX_BUTTONS 5
static char ButtonNames[MAX_BUTTONS][80];

extern void autoglcallback0_ (void);
extern void autoglcallback1_ (void);
extern void autoglcallback2_ (void);
extern void autoglcallback3_ (void);
extern void autoglcallback4_ (void);

static char String[256];

static void SetString (const char *str, int length)
{
  int i;
  
  assert(length < 256 - 1);
  for (i = 0; i < length; i++) {
    String[i] = str[i];
  } 
  String[i] = 0;
}

void autoglsetcolor_
(double *red, double *green, double *blue)
{
  AutoGL_SetColor (*red, *green, *blue);
}

void autogldrawline_
(double *x0, double *y0, double *z0,    
 double *x1, double *y1, double *z1)
{
  AutoGL_DrawLine 
    (*x0, *y0, *z0,    
     *x1, *y1, *z1); 
}

void autogldrawtriangle_
(double *x0, double *y0, double *z0,  
 double *x1, double *y1, double *z1,  
 double *x2, double *y2, double *z2)
{
  AutoGL_DrawTriangle 
    (*x0, *y0, *z0,  
     *x1, *y1, *z1,  
     *x2, *y2, *z2);
}
  
void autogldrawcontourtriangle_
(double *x0, double *y0, double *z0, double *grade0,  
 double *x1, double *y1, double *z1, double *grade1,  
 double *x2, double *y2, double *z2, double *grade2)
{
  AutoGL_DrawContourTriangle 
    (*x0, *y0, *z0, *grade0,  
     *x1, *y1, *z1, *grade1,  
     *x2, *y2, *z2, *grade2); 
}

void autogldrawquadrangle_
(double *x0, double *y0, double *z0,
 double *x1, double *y1, double *z1,
 double *x2, double *y2, double *z2,
 double *x3, double *y3, double *z3)
{
  AutoGL_DrawQuadrangle 
    (*x0, *y0, *z0,
     *x1, *y1, *z1,
     *x2, *y2, *z2,
     *x3, *y3, *z3);
}

void autogldrawstring_
(double *x, double *y, double *z,
 const char *str, int length)
{
  SetString (str, length);
  AutoGL_DrawString 
    (*x, *y, *z,
     String);
}

void autoglsetbackgroundcolor_ 
(double *red, double *green, double *blue)
{
  AutoGL_SetBackgroundColor 
    (*red, *green, *blue);
}
  
void autoglgetcontourcolor_
(double *red_OUT, double *green_OUT, double *blue_OUT,
 double *grade)
{
  AutoGL_GetContourColor 
    (red_OUT, green_OUT, blue_OUT,
     *grade);
}

void autoglopendisplaylist_ (void)
{
  AutoGL_OpenDisplayList ();
}

void autoglclosedisplaylist_ (void)
{
  AutoGL_CloseDisplayList ();
}

void autogldrawdisplaylist_ (void)
{
  AutoGL_DrawDisplayList ();
}

void autoglsetviewsize_ (double *size)
{
  AutoGL_SetViewSize (*size);
}

void autoglsetviewcenter_
(double *x, double *y, double *z)
{
  AutoGL_SetViewCenter (*x, *y, *z);
}

void autoglsetviewdirection_ 
(double *x, double *y, double *z)
{
  AutoGL_SetViewDirection (*x, *y, *z);
}

void autoglsetviewupvector_
(double *x, double *y, double *z)
{
  AutoGL_SetViewUpVector (*x, *y, *z);
}

void autoglgetviewsize_ (double *size)
{
  *size = AutoGL_GetViewSize ();
}

void autoglgetviewcenter_
(double *x_OUT, double *y_OUT, double *z_OUT)
{
  AutoGL_GetViewCenter 
    (x_OUT, y_OUT, z_OUT);
}

void autoglgetviewdirection_
(double *x_OUT, double *y_OUT, double *z_OUT)
{
  AutoGL_GetViewDirection 
    (x_OUT, y_OUT, z_OUT);
}

void autoglgetviewupvector_
(double *x_OUT, double *y_OUT, double *z_OUT)
{
  AutoGL_GetViewUpVector 
    (x_OUT, y_OUT, z_OUT);
}

void autoglgetviewrangedc_
(int *widthDc_OUT, int *heightDc_OUT)
{
  AutoGL_GetViewRangeDc 
    (widthDc_OUT, heightDc_OUT);
}

void autoglgetvcofdc_
(double *vcX_OUT, double *vcY_OUT, double *vcZ_OUT,
 int *dcX, int *dcY, int *dcZ)
{
  AutoGL_GetVcOfDc 
    (vcX_OUT, vcY_OUT, vcZ_OUT,
     *dcX, *dcY, *dcZ);
}

void autoglgetpositionofvc_
(double *x_OUT, double *y_OUT, double *z_OUT,
 double *vcX, double *vcY, double *vcZ)
{
  AutoGL_GetPositionOfVc 
    (x_OUT, y_OUT, z_OUT,
     *vcX, *vcY, *vcZ);
}
  
void autoglgetpositionofdc_ 
(double *x_OUT, double *y_OUT, double *z_OUT,
 int *dcX, int *dcY, int *dcZ)
{
  AutoGL_GetPositionOfDc 
    (x_OUT, y_OUT, z_OUT,
     *dcX, *dcY, *dcZ);
}

void autogldrawview_ (void)
{
  AutoGL_DrawView ();
}

void autogladdgroup_
(const char *name, int length)
{
  SetString (name, length);
  AutoGL_AddGroup (String);
}

void autogladdcomment_ (void)
{
  AutoGL_AddComment ();
}

void autogladdboolean_ 
(int *value_IO, 
 const char *name, int length)
{
  SetString (name, length);
  AutoGL_AddBoolean 
    (value_IO, 
     String);
}

void autogladdinteger_
(int *value_IO, 
 const char *name, int length)
{
  SetString (name, length);
  AutoGL_AddInteger 
    (value_IO, 
     String);
}

void autoglsetintegerrange_
(int *minValue, int *maxValue)
{
  AutoGL_SetIntegerRange 
    (*minValue, *maxValue);
}

void autogladdintegeritem_
(const char *label, int length)
{
  SetString (label, length);
  AutoGL_AddIntegerItem 
    (String);
}

void autogladdreal_
(double *value_IO, 
 const char *name, int length)
{
  SetString (name, length);
  AutoGL_AddReal 
    (value_IO, 
     String);
}

void autoglsetrealrange_
(double *minValue, double *maxValue)
{
  AutoGL_SetRealRange 
    (*minValue, *maxValue);
}

void autoglsetlabel_
(const char *label, int length)
{
  SetString (label, length);
  AutoGL_SetLabel 
    (String);
}

void autoglsetbutton_
(int *id, const char *label, int length)
{
  assert(0 <= *id);
  assert(*id < MAX_BUTTONS);
  SetString (label, length);
  strcpy (ButtonNames[*id], String);
}



/* NEED TO REDEFINE */
/* Unix only solution */
/* How can I call WinMain() in case of Cygwin ? */
int MAIN__()
{
  return main (0, NULL);
}

void AutoGL_SetUp (int argc, char *argv[])
{
  AutoGL_SetViewRedrawCallback (autoglredraw_);
  AutoGL_SetDefaultCallbackInMode3D (NULL);
  AutoGL_SetPanelInMode3D ();

  autoglsetup_ ();

  if (0 < strlen (ButtonNames[0])) {
    AutoGL_AddCallback (autoglcallback0_, ButtonNames[0]); 
  }
  if (0 < strlen (ButtonNames[1])) {
    AutoGL_AddCallback (autoglcallback1_, ButtonNames[1]); 
  }
  if (0 < strlen (ButtonNames[2])) {
    AutoGL_AddCallback (autoglcallback2_, ButtonNames[2]); 
  }
  if (0 < strlen (ButtonNames[3])) {
    AutoGL_AddCallback (autoglcallback3_, ButtonNames[3]); 
  }
  if (0 < strlen (ButtonNames[4])) {
    AutoGL_AddCallback (autoglcallback4_, ButtonNames[4]); 
  }
}

