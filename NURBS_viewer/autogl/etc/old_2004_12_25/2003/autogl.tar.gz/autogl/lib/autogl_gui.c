/* autogl_gui.c : window system and grphical user interface */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "autogl_math.h"
#include "autogl_uims.h"
#include "autogl_os.h"
#include "autogl_graphics.h"
#include "autogl_gui.h"

#include "autogl_uims_inside.h"
#include "autogl_graphics_inside.h"



/* Module Variables */




