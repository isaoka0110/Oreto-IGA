/* AutoGL */

#ifndef __AUTOGL_OS__
#define __AUTOGL_OS__

/* OS$B0MB8=hM}(B */



#endif  /* __AUTOGL_OS__ */



