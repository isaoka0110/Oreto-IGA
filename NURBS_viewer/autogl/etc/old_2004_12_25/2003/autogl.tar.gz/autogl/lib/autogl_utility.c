/* autogl_utility.c : AutoGL utility */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "autogl_math.h"
#include "autogl_uims.h"
#include "autogl_os.h"
#include "autogl_graphics.h"
#include "autogl_gui.h"
#include "autogl_cui.h"
#include "autogl_utility.h"



/* Command Line Interface and Scripting */

static char ScriptFileName[256];

static void GoToCommandLineMode (void)
{
  AutoGL_InterpretInInteractiveMode ();
}

static void RunScript (void)
{
  AutoGL_InterpretScript (ScriptFileName);
}

void AutoGL_SetPanelForInterpreter (void)
{
  AutoGL_AddComment ();
  AutoGL_SetLabel ("INTERPRETER");
  AutoGL_AddCallback (GoToCommandLineMode, 
		      "AutoGL_GoToCommandLineMode"); 
  AutoGL_SetLabel ("command line"); 
  AutoGL_AddCallback (RunScript, "AutoGL_RunScript"); 
  AutoGL_SetLabel ("run script"); 
  AutoGL_AddString (ScriptFileName, "AutoGL_ScriptFileName", 256); 
  AutoGL_SetLabel ("file"); 
}




/* Drawing Primitive */

#define BLUE_RATIO    (0.0)
#define CYAN_RATIO    (1.0 / 21 * 5)
#define GREEN_RATIO   (1.0 / 21 * 8)
#define YELLOW_RATIO  (1.0 / 21 * 11)
#define RED_RATIO     (1.0 / 21 * 16)
#define MAGENTA_RATIO (1.0)
 
void AutoGL_GetContourColor 
(double *red_OUT, double *green_OUT, double *blue_OUT,
 double grade)
{
  if (grade < BLUE_RATIO) {
    *red_OUT = 0.0;  
    *green_OUT = 0.0;  
    *blue_OUT = 1.0;
  } else if (grade < CYAN_RATIO) {
    double v = (grade - BLUE_RATIO) / (CYAN_RATIO - BLUE_RATIO);
    *red_OUT = 0.0;  
    *green_OUT = v;  
    *blue_OUT = 1.0;
  } else if (grade < GREEN_RATIO) {
    double v = 1.0 - (grade - CYAN_RATIO) / (GREEN_RATIO - CYAN_RATIO);
    *red_OUT = 0.0;  
    *green_OUT = 1.0;  
    *blue_OUT = v;
  } else if (grade < YELLOW_RATIO) {
    double v = (grade - GREEN_RATIO) / (YELLOW_RATIO - GREEN_RATIO);
    *red_OUT = v;  
    *green_OUT = 1.0;  
    *blue_OUT = 0.0;
  } else if (grade < RED_RATIO) {
    double v = 1.0 - (grade - YELLOW_RATIO) / (RED_RATIO - YELLOW_RATIO);
    *red_OUT = 1.0;  
    *green_OUT = v;  
    *blue_OUT = 0.0;
  } else if (grade < MAGENTA_RATIO) {
    double v = (grade - RED_RATIO) / (MAGENTA_RATIO - RED_RATIO);
    *red_OUT = 1.0;  
    *green_OUT = 0.0;  
    *blue_OUT = v;
  } else {
    *red_OUT = 1.0;  
    *green_OUT = 0.0;  
    *blue_OUT = 1.0;
  }
}

void AutoGL_DrawContourTriangle 
(double x0, double y0, double z0, double grade0, 
 double x1, double y1, double z1, double grade1, 
 double x2, double y2, double z2, double grade2)
{
  double red0, green0, blue0;
  double red1, green1, blue1;
  double red2, green2, blue2;

  AutoGL_GetContourColor (&red0, &green0, &blue0,
			  grade0);
  AutoGL_GetContourColor (&red1, &green1, &blue1,
			  grade1);
  AutoGL_GetContourColor (&red2, &green2, &blue2,
			  grade2);
  AutoGL_DrawColorInterpolatedTriangle 
    (x0, y0, z0, red0, green0, blue0,
     x1, y1, z1, red1, green1, blue1,
     x2, y2, z2, red2, green2, blue2);
}

void AutoGL_DrawContourMap 
(int sizeDc,
 double minRange, double maxRange)
{
  int widthDc, heightDc;
  int corner0XDc, corner0YDc;
  int corner1XDc, corner1YDc;
  int nGrades = 10;
  int iGrade;
  char buf[256];
  
  AutoGL_GetViewRangeDc (&widthDc, &heightDc);
  
  corner0XDc = widthDc / 2 - sizeDc;
  corner1XDc = widthDc / 2 - sizeDc / 4 * 3;
  corner0YDc = -heightDc / 2 + sizeDc / 4;
  corner1YDc = heightDc / 2 - sizeDc / 4;

  for (iGrade = 0; iGrade < nGrades; iGrade++) {
    double grade0 = 1.0 / nGrades * iGrade;
    double grade1 = 1.0 / nGrades * (iGrade + 1);
    int p0YDc = corner0YDc 
      + (corner1YDc - corner0YDc) * iGrade / nGrades;
    int p1YDc = corner0YDc 
      + (corner1YDc - corner0YDc) * (iGrade + 1) / nGrades;
    double p00X, p00Y, p00Z;
    double p01X, p01Y, p01Z;
    double p11X, p11Y, p11Z;
    double p10X, p10Y, p10Z;
    
    AutoGL_GetPositionOfDc (&p00X, &p00Y, &p00Z,
			    corner0XDc, p0YDc, 0);
    AutoGL_GetPositionOfDc (&p01X, &p01Y, &p01Z,
			    corner1XDc, p0YDc, 0);
    AutoGL_GetPositionOfDc (&p11X, &p11Y, &p11Z,
			    corner1XDc, p1YDc, 0);
    AutoGL_GetPositionOfDc (&p10X, &p10Y, &p10Z,
			    corner0XDc, p1YDc, 0);
    AutoGL_DrawContourTriangle 
      (p00X, p00Y, p00Z, grade0,
       p01X, p01Y, p01Z, grade0,
       p11X, p11Y, p11Z, grade1);
    AutoGL_DrawContourTriangle 
      (p11X, p11Y, p11Z, grade1,
       p10X, p10Y, p10Z, grade1,
       p00X, p00Y, p00Z, grade0);

    sprintf (buf, "%4.1e", 
	     minRange + (maxRange - minRange) / nGrades * iGrade);
    AutoGL_DrawString (p01X, p01Y, p01Z, 
		       buf);  

    if (iGrade == nGrades - 1) {
      sprintf (buf, "%4.1e", maxRange);
      AutoGL_DrawString (p11X, p11Y, p11Z, 
			 buf);  
    }
  }
}

void AutoGL_DrawLineContourMap 
(int sizeDc,
 double minRange, double maxRange,
 int nGrades)
{
  int widthDc, heightDc;
  int corner0XDc, corner0YDc;
  int corner1XDc, corner1YDc;
  int iGrade;
  char buf[256];
  
  AutoGL_GetViewRangeDc (&widthDc, &heightDc);
  
  corner0XDc = widthDc / 2 - sizeDc;
  corner1XDc = widthDc / 2 - sizeDc / 4 * 3;
  corner0YDc = -heightDc / 2 + sizeDc / 4;
  corner1YDc = heightDc / 2 - sizeDc / 4;

  {
    double p0X, p0Y, p0Z;
    double p1X, p1Y, p1Z;

    AutoGL_SetColor (1, 1, 1);
    AutoGL_GetPositionOfDc (&p0X, &p0Y, &p0Z,
			    corner0XDc, corner0YDc, 0);
    AutoGL_GetPositionOfDc (&p1X, &p1Y, &p1Z,
			    corner0XDc, corner1YDc, 0);
    AutoGL_DrawLine 
      (p0X, p0Y, p0Z,
       p1X, p1Y, p1Z);
    AutoGL_GetPositionOfDc (&p0X, &p0Y, &p0Z,
			    corner1XDc, corner0YDc, 0);
    AutoGL_GetPositionOfDc (&p1X, &p1Y, &p1Z,
			    corner1XDc, corner1YDc, 0);
    AutoGL_DrawLine 
      (p0X, p0Y, p0Z,
       p1X, p1Y, p1Z);
  }

  for (iGrade = 0; iGrade <= nGrades; iGrade++) {
    double grade = 1.0 / nGrades * iGrade;
    double red, green, blue;
    int pYDc = corner0YDc 
      + (corner1YDc - corner0YDc) * iGrade / nGrades;
    double p0X, p0Y, p0Z;
    double p1X, p1Y, p1Z;
    
    AutoGL_GetContourColor (&red, &green, &blue,
			    grade);
    AutoGL_SetColor (red, green, blue);
    AutoGL_GetPositionOfDc (&p0X, &p0Y, &p0Z,
			    corner0XDc, pYDc, 0);
    AutoGL_GetPositionOfDc (&p1X, &p1Y, &p1Z,
			    corner1XDc, pYDc, 0);
    AutoGL_DrawLine 
      (p0X, p0Y, p0Z,
       p1X, p1Y, p1Z);

    sprintf (buf, "%4.1e", 
	     minRange + (maxRange - minRange) / nGrades * iGrade);
    AutoGL_DrawString (p1X, p1Y, p1Z, 
		       buf);  
  }
}



/* Visualization */

int AutoGL_HexToTetraMap[6][4] = {
  { 0, 1, 2, 5 }, 
  { 0, 5, 2, 6 }, 
  { 0, 5, 6, 4 }, 
  { 0, 2, 3, 6 }, 
  { 0, 4, 6, 7 }, 
  { 0, 6, 3, 7 }
};

static int TriangleEdgeVertexMap[3][2] = {
  { 0, 1 }, { 1, 2 }, { 2, 0 }
};

typedef struct {
  int nEdges;
  int edges[2];
} TriangleEdgeCase;

static TriangleEdgeCase TriangleEdgeCases[4] = {
  { 0, { -1, -1 } },
  { 2, { 0, 2 } },
  { 2, { 0, 1 } },
  { 2, { 1, 2 } }
};

static int TetrahedronEdgeVertexMap[6][2] = {
  { 0, 1 }, { 1, 2 }, { 2, 0 }, 
  { 0, 3 }, { 1, 3 }, { 2, 3 }
};

typedef struct {
  int nEdges;
  int edges[4];
} TetrahedronEdgeCase;

static TetrahedronEdgeCase TetrahedronEdgeCases[8] = {
  { 0, { 0, -1, -1, -1 } },
  { 3, { 0, 2, 3, -1 } },
  { 3, { 0, 1, 4, -1 } },
  { 4, { 1, 2, 3, 4 } },
  { 3, { 1, 2, 5, -1 } },
  { 4, { 0, 1, 5, 3 } },
  { 4, { 0, 4, 5, 2 } },
  { 3, { 3, 4, 5, -1 } }
};

int AutoGL_GetIsoline 
(int vertexIds0_OUT[2],
 int vertexIds1_OUT[2],
 double ratios_OUT[2],
 double levelValue, 
 double triValues[3])
{
  unsigned int mask;
  int nEdges;
  int iEdge;

  mask = 0;
  if (levelValue < triValues[0]) mask |= 1;
  if (levelValue < triValues[1]) mask |= 2;
  if (levelValue < triValues[2]) mask |= 4;
  if ((mask & 4) != 0) mask = (~mask) & 7;

  nEdges = TriangleEdgeCases[mask].nEdges;
  if (nEdges == 0) return 0;
  
  assert(nEdges == 2);

  for (iEdge = 0; iEdge < nEdges; iEdge++) {
    int edgeId = TriangleEdgeCases[mask].edges[iEdge];
    int v0 = TriangleEdgeVertexMap[edgeId][0];
    int v1 = TriangleEdgeVertexMap[edgeId][1];
    double ratio = (levelValue - triValues[v0]) 
      / (triValues[v1] - triValues[v0]);
    
    vertexIds0_OUT[iEdge] = v0; 
    vertexIds1_OUT[iEdge] = v1;
    ratios_OUT[iEdge] = ratio;
  }    

  return 1;
}

void AutoGL_GetIsolineVertex 
(double points_OUT[2][3],
 double triPoints[3][3], 
 int vertexIds0[2],
 int vertexIds1[2],
 double ratios[2])
{
  int iVertex;

  for (iVertex = 0; iVertex < 2; iVertex++) {
    int v0 = vertexIds0[iVertex];
    int v1 = vertexIds1[iVertex];
    double ratio = ratios[iVertex];

    points_OUT[iVertex][0] = triPoints[v0][0] 
      + (triPoints[v1][0] - triPoints[v0][0]) * ratio;
    points_OUT[iVertex][1] = triPoints[v0][1] 
      + (triPoints[v1][1] - triPoints[v0][1]) * ratio;
    points_OUT[iVertex][2] = triPoints[v0][2] 
      + (triPoints[v1][2] - triPoints[v0][2]) * ratio;
  }
}

void AutoGL_DrawTriangleIsoline 
(double levelValue,
 double triPoints[3][3],
 double triValues[3])
{
  int vertexIds0[2], vertexIds1[2];
  double ratios[2];
      
  if (AutoGL_GetIsoline
      (vertexIds0, vertexIds1, ratios,
       levelValue, triValues)) {
    double points[2][3];
    
    AutoGL_GetIsolineVertex 
      (points,
       triPoints, vertexIds0, vertexIds1, ratios);
    AutoGL_DrawLine 
      (points[0][0], points[0][1], points[0][2],
       points[1][0], points[1][1], points[1][2]);
  }
}

int AutoGL_GetIsosurface 
(int *nVertexs_OUT,
 int vertexIds0_OUT[4],
 int vertexIds1_OUT[4],
 double ratios_OUT[4],
 double levelValue, 
 double tetraValues[4])
{
  unsigned int mask;
  int nEdges;
  int iEdge;

  mask = 0;
  if (levelValue < tetraValues[0]) mask |= 1;
  if (levelValue < tetraValues[1]) mask |= 2;
  if (levelValue < tetraValues[2]) mask |= 4;
  if (levelValue < tetraValues[3]) mask |= 8;
  if ((mask & 8) != 0) mask = (~mask) & 15;

  nEdges = TetrahedronEdgeCases[mask].nEdges;
  if (nEdges <= 2) return 0;
  assert(nEdges == 3 || nEdges == 4);

  *nVertexs_OUT = nEdges;
  for (iEdge = 0; iEdge < nEdges; iEdge++) {
    int edgeId = TetrahedronEdgeCases[mask].edges[iEdge];
    int v0 = TetrahedronEdgeVertexMap[edgeId][0];
    int v1 = TetrahedronEdgeVertexMap[edgeId][1];
    double ratio = (levelValue - tetraValues[v0]) 
      / (tetraValues[v1] - tetraValues[v0]);

    vertexIds0_OUT[iEdge] = v0; 
    vertexIds1_OUT[iEdge] = v1;
    ratios_OUT[iEdge] = ratio;
  }

  return 1;
}

void AutoGL_GetIsosurfaceVertex 
(double points_OUT[4][3],
 double tetraPoints[4][3], 
 int nVertexs, 
 int vertexIds0[4],
 int vertexIds1[4],
 double ratios[4])
{
  int iVertex;

  assert(nVertexs == 3 || nVertexs == 4);

  for (iVertex = 0; iVertex < nVertexs; iVertex++) {
    int v0 = vertexIds0[iVertex];
    int v1 = vertexIds1[iVertex];
    double ratio = ratios[iVertex];

    points_OUT[iVertex][0] = tetraPoints[v0][0] 
      + (tetraPoints[v1][0] - tetraPoints[v0][0]) * ratio;
    points_OUT[iVertex][1] = tetraPoints[v0][1] 
      + (tetraPoints[v1][1] - tetraPoints[v0][1]) * ratio;
    points_OUT[iVertex][2] = tetraPoints[v0][2] 
      + (tetraPoints[v1][2] - tetraPoints[v0][2]) * ratio;
  }
}

void AutoGL_DrawTetrahedronIsosurface 
(double levelValue,
 double tetraPoints[4][3],
 double tetraValues[4])
{
  int nVertexs;
  int vertexIds0[4], vertexIds1[4];
  double ratios[4];
  
  if (AutoGL_GetIsosurface
      (&nVertexs, vertexIds0, vertexIds1, ratios,
       levelValue, tetraValues)) {
    double points[4][3];
    
    AutoGL_GetIsosurfaceVertex 
      (points, 
       tetraPoints, 
       nVertexs, vertexIds0, vertexIds1, ratios);
    
    assert (nVertexs == 3 || nVertexs == 4);
    AutoGL_DrawTriangle (points[0][0], points[0][1], points[0][2],
			 points[1][0], points[1][1], points[1][2],
			 points[2][0], points[2][1], points[2][2]);
    if (nVertexs == 4) {
      AutoGL_DrawTriangle (points[2][0], points[2][1], points[2][2],
			   points[3][0], points[3][1], points[3][2],
			   points[0][0], points[0][1], points[0][2]);
    }
  }
}

void AutoGL_DrawTetrahedronSectionContour 
(double a, double b, double c, double d,
 double tetraPoints[4][3],
 double tetraGrades[4])
{
  int iVertex;
  double tetraEquationValues[4];
  int nVertexs;
  int vertexIds0[4], vertexIds1[4];
  double ratios[4];

  for (iVertex = 0; iVertex < 4; iVertex++) {
    double x = tetraPoints[iVertex][0];
    double y = tetraPoints[iVertex][1];
    double z = tetraPoints[iVertex][2];
    tetraEquationValues[iVertex] = a * x + b * y + c * z + d;
  }
  
  if (AutoGL_GetIsosurface
      (&nVertexs, vertexIds0, vertexIds1, ratios,
       0.0, tetraEquationValues)) {
    double points[4][3];
    double grades[4];
    
    AutoGL_GetIsosurfaceVertex 
      (points, 
       tetraPoints, 
       nVertexs, vertexIds0, vertexIds1, ratios);
    
    for (iVertex = 0; iVertex < nVertexs; iVertex++) {
      int v0 = vertexIds0[iVertex];
      int v1 = vertexIds1[iVertex];
      double ratio = ratios[iVertex];
      
      grades[iVertex] = tetraGrades[v0] 
	+ (tetraGrades[v1] - tetraGrades[v0]) * ratio;
    }

    assert (nVertexs == 3 || nVertexs == 4);
    AutoGL_DrawContourTriangle 
      (points[0][0], points[0][1], points[0][2], grades[0], 
       points[1][0], points[1][1], points[1][2], grades[1],
       points[2][0], points[2][1], points[2][2], grades[2]);
    if (nVertexs == 4) {
      AutoGL_DrawContourTriangle 
	(points[2][0], points[2][1], points[2][2], grades[2],
	 points[3][0], points[3][1], points[3][2], grades[3],
	 points[0][0], points[0][1], points[0][2], grades[0]);
    }
  }
}



/* File I/O */

static char ImageFileName[256] = "image.ppm";

void AutoGL_SaveViewImageToPPMFile (const char *fileName)
{
  FILE *fp;
  int widthDc, heightDc;
  unsigned char *image;
  int iRow;

  AutoGL_GetViewRangeDc (&widthDc, &heightDc);
  image = (unsigned char *)malloc (widthDc * heightDc * 3);
  assert(image != NULL);
  AutoGL_GetViewImage (image);

  fp = fopen (fileName, "wb");
  assert(fp != NULL);
  fprintf (fp, "P6\n%d %d\n255\n", 
	   widthDc, heightDc);
  for (iRow = heightDc - 1; 0 <= iRow; iRow--) {
    fwrite (&image[widthDc * 3 * iRow], widthDc * 3, 1, fp);
  }
  fclose (fp);

  free (image);
}

void AutoGL_ReadImageFromPPMFile 
(const char *fileName,
 int *widthDcPtr_OUT, int *heightDcPtr_OUT, unsigned char **imagePtr_OUT)
{
  FILE *fp;
  int widthDc, heightDc;
  unsigned char *image;
  int iRow;
  char line[256];

  fp = fopen (fileName, "r");
  assert(fp != NULL);

  fgets (line,  256, fp);
  assert(strcmp (line, "P6\n") == 0);

  fgets (line,  256, fp);
  sscanf (line, "%d %d\n", 
	  &widthDc, &heightDc);
  assert(0 < widthDc);
  assert(0 < heightDc);

  fgets (line,  256, fp);
  assert(strcmp (line, "255\n") == 0);

  image = (unsigned char *)malloc (widthDc * heightDc * 3);
  assert(image != NULL);
  for (iRow = heightDc - 1; 0 <= iRow; iRow--) {
    fread (&image[widthDc * 3 * iRow], widthDc * 3, 1, fp);
  }

  fclose (fp);

  *widthDcPtr_OUT = widthDc;
  *heightDcPtr_OUT = heightDc;
  *imagePtr_OUT = image;
}

static void SaveViewImage (void) 
{
  AutoGL_SaveViewImageToPPMFile (ImageFileName);
}

void AutoGL_SetPanelForSave (void)
{
  AutoGL_AddComment ();
  AutoGL_SetLabel ("SAVE");
  AutoGL_AddCallback (SaveViewImage, "AutoGL_SaveViewImage");
  AutoGL_SetLabel ("save image");
  AutoGL_AddString (ImageFileName, "AutoGL_ImageFileName", 256); 
  AutoGL_SetLabel ("file");
}






