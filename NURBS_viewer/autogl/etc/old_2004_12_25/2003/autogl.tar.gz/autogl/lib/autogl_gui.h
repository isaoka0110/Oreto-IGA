/* AutoGL */

#ifndef __AUTOGL_GUI__
#define __AUTOGL_GUI__

/* $B%0%i%U%#%+%k%f!<%6!<%$%s%?!<%U%'%$%9=hM}(B */



/* $B%S%e!<$r:FIA2h$9$k!#(B */
void AutoGL_DrawView (void);
/* $B%S%e!<$N:FIA2h4X?t$,8F$S=P$5$l$k!#(B */



#endif  /* __AUTOGL_GUI__ */



