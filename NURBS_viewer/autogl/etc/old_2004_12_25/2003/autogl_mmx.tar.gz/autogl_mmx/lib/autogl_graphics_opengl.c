/* autogl_graphics_opengl.c : OpenGL rendering */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include <autonosim.h>

#include "autogl_math.h"
#include "autogl_graphics.h"

#include "autogl_graphics_inside.h"
#include "autogl_graphics_opengl_inside.h"



/* Module Variables */

/* background color of the view window */
static double View_backgroundRed;
static double View_backgroundGreen;
static double View_backgroundBlue;

/* ratio of Z direction (depth) against X and Y direction 
   in the viewing coordinate system of the clipping volume */
static const double View_depthRatio = 5.0;

/* size ratio between near plane and center plane */
/* 1.0 < perspectiveRatio */
static const double View_nearPerspectiveRatio = 3.0;
static const double View_farPerspectiveRatio = 50.0;

/* whether lighting is on/off */
static int View_lightIsOn;

/* whether transparency is on/off */
static int View_transparencyIsOn;

/* OpenGL list base for character string */
/* 128 OpenGL lists (No. 0 - 127) are reserved for drawing character string. */
static GLuint View_charBase;

/* OpenGL list No. for display list */
static const int View_DisplayListId = 200;

/* OpenGL selection buffer and hit record */
#define MAX_SELECT_BUFFER_SIZE 1024
static GLuint View_selectBuffer[MAX_SELECT_BUFFER_SIZE];
static int View_nHits;

/* MMX : difference between left and right eyes in stereo viewing */
static const double StereoRatio = 0.01;






/* AutoGL MMX specific */

/* modify viewing direction for stereo vision */
static void ModifyDirection 
(double *dirX, double *dirY, double *dirZ)
{  
  double upX, upY, upZ;
  double xAxisX, xAxisY, xAxisZ;
      
  AutoGL_GetViewUpVector 
    (&upX, &upY, &upZ);
  AutoGL_GetVectorProduct3D 
    (&xAxisX, &xAxisY, &xAxisZ,
     upX, upY, upZ,
     *dirX, *dirY, *dirZ);
  AutoGL_NormalizeVector3D (&xAxisX, &xAxisY, &xAxisZ,
			    xAxisX, xAxisY, xAxisZ);
  if (AutoNOSim_MyTaskId () % 2 == 0) {
    /* right hand side eye */
    *dirX += xAxisX * StereoRatio;
    *dirY += xAxisY * StereoRatio;
    *dirZ += xAxisZ * StereoRatio;
  } else {   
    /* left hand side eye */
    *dirX -= xAxisX * StereoRatio;
    *dirY -= xAxisY * StereoRatio;
    *dirZ -= xAxisZ * StereoRatio;
  }
}






static void SetProjection (void)
{
  GLfloat size;
  int widthDc, heightDc;
  GLfloat halfWidth, halfHeight;

  size = AutoGL_GetViewSize ();
  AutoGL_GetViewRangeDc 
    (&widthDc, &heightDc);

  if (widthDc <= heightDc) {
    halfWidth = size;
    halfHeight = size * heightDc / widthDc;
  } else {
    halfWidth = size * widthDc / heightDc;
    halfHeight = size;
  }

  if (AutoGL_GetPerspectiveViewFlag ()) {
    /* set perspective projection */
    glFrustum (-halfWidth / View_nearPerspectiveRatio, 
	       halfWidth / View_nearPerspectiveRatio, 
	       -halfHeight / View_nearPerspectiveRatio, 
	       halfHeight / View_nearPerspectiveRatio, 
	       size * 1.0, 
	       size * View_farPerspectiveRatio);
  } else {
    /* set orthogonal projection */
    glOrtho (-halfWidth, halfWidth, 
	     -halfHeight, halfHeight, 
	     -size * View_depthRatio, size * View_depthRatio);
  }
} 

static void SetViewingTransformation (void)
{
  double centerX, centerY, centerZ;
  double dirX, dirY, dirZ;
  double upX, upY, upZ;
  GLfloat size;

  AutoGL_GetViewCenter 
    (&centerX, &centerY, &centerZ);
  AutoGL_GetViewDirection 
    (&dirX, &dirY, &dirZ);
  AutoGL_GetViewUpVector 
    (&upX, &upY, &upZ);
  size = AutoGL_GetViewSize ();

  ModifyDirection 
    (&dirX, &dirY, &dirZ);

  /* set viewing transformation */
  if (AutoGL_GetPerspectiveViewFlag ()) {
    gluLookAt (centerX + dirX * size * View_nearPerspectiveRatio, 
	       centerY + dirY * size * View_nearPerspectiveRatio, 
	       centerZ + dirZ * size * View_nearPerspectiveRatio,
	       centerX, centerY, centerZ,
	       upX, upY, upZ);
  } else {
    gluLookAt (centerX + dirX, 
	       centerY + dirY, 
	       centerZ + dirZ,
	       centerX, centerY, centerZ,
	       upX, upY, upZ);
  }
}

static void TurnOnLighting (void)
{
  if (!View_lightIsOn) {

    /* turn on lighting */
    glEnable (GL_LIGHTING);

    View_lightIsOn = 1;
  }
}

static void TurnOffLighting (void)
{
  if (View_lightIsOn) {

    /* turn off lighting */
    glDisable (GL_LIGHTING);

    View_lightIsOn = 0;
  }
}

static int GatherSelectedId (int selectedId, unsigned int minZ)
{
  int result = -1;

  AutoNOSim_Clear (AUTONOSIM_PACKING);
  AutoNOSim_Integer (&selectedId);
  AutoNOSim_Integer ((int *)&minZ);
  AutoNOSim_SendTo (AUTONOSIM_MASTER_TASK_ID);

  if (AutoNOSim_MyTaskId () == AUTONOSIM_MASTER_TASK_ID) {
    int nTasks = AutoNOSim_NTasks ();
    int iTask;
    int masterSelectedId = -1;
    unsigned int masterMinZ = 0;
    
    for (iTask = 0; iTask < nTasks; iTask++) {
      int slaveSelectedId;
      unsigned int slaveMinZ;
      
      AutoNOSim_ReceiveFrom (iTask);
      AutoNOSim_Clear (AUTONOSIM_UNPACKING);
      AutoNOSim_Integer (&slaveSelectedId);
      AutoNOSim_Integer ((int *)&slaveMinZ);

      if (0 <= slaveSelectedId) {
	if (masterSelectedId < 0
	    || slaveMinZ < masterMinZ) {
	  masterSelectedId = slaveSelectedId;
	  masterMinZ = slaveMinZ;
	}
      }
    }

    for (iTask = 0; iTask < nTasks; iTask++) {
      AutoNOSim_Clear (AUTONOSIM_PACKING);
      AutoNOSim_Integer (&masterSelectedId);
      AutoNOSim_SendTo (iTask);
    }
  }

  AutoNOSim_ReceiveFrom (AUTONOSIM_MASTER_TASK_ID);
  AutoNOSim_Clear (AUTONOSIM_UNPACKING);
  AutoNOSim_Integer (&result);

  return result;
}

void AutoGL_SetBackgroundColor 
(double red, double green, double blue)
{
  View_backgroundRed = red;
  View_backgroundGreen = green;
  View_backgroundBlue = blue;
}

void AutoGL_RealizeOpenGLWindow (void)
{
  GLfloat ambientLightColor[] = { 0.2f, 0.2f, 0.2f, 1.0f };
  GLfloat diffuseLightColor[] = { 0.8f, 0.8f, 0.8f, 1.0f };
  GLfloat specularLightColor[] = { 1.0f, 1.0f, 1.0f, 1.0f };
  GLfloat lightPosition[4];

  /* set background color */
  glClearColor (View_backgroundRed, 
		View_backgroundGreen, 
		View_backgroundBlue, 
		1.0f);
  
  /* set foreground color : white */
  glColor3f (1.0f, 1.0f, 1.0f);
  
  /* turn on depth test */
  glEnable (GL_DEPTH_TEST);
  
  /* turn on face culling */
  glFrontFace (GL_CCW);
  glEnable (GL_CULL_FACE);
  
  /* turn off transparency */
  glDisable (GL_BLEND);
  View_transparencyIsOn = 0;

  /* turn on lighting */
  glEnable (GL_LIGHTING);
  View_lightIsOn = 1;
  
  /* set ambient light */
  glLightModelfv (GL_LIGHT_MODEL_AMBIENT, ambientLightColor);
  
  /* turn on material color tracking */
  glEnable (GL_COLOR_MATERIAL);
  
  /* specify ambient and diffuse as tracking color */
  glColorMaterial (GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
  
  /* set color at light No. 0 */
  glLightfv (GL_LIGHT0, GL_DIFFUSE, diffuseLightColor);
  glLightfv (GL_LIGHT0, GL_SPECULAR, specularLightColor);
  
  /* set position at light No. 0 : directional light */
  lightPosition[0] = 0.0f;
  lightPosition[1] = 0.0f;
  lightPosition[2] = 1.0f;
  lightPosition[3] = 0.0f;
  glLightfv (GL_LIGHT0, GL_POSITION, lightPosition);

  /* turn on light No. 0 */
  glEnable (GL_LIGHT0);

  /* allocate lists of bitmaps for OpenGL character string drawing */
  View_charBase = glGenLists (128);

  /* turn on edge contrasting */
  glEnable (GL_POLYGON_OFFSET_FILL);
  glPolygonOffset( 1.0, 1.0 );

  /* set alignment of pixel-level operation as 1 */
  glPixelStorei (GL_PACK_ALIGNMENT, 1);
  glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
} 

void AutoGL_StartDrawingOpenGLWindow (void)
{
  static GLfloat noColor[] = { 0.0f, 0.0f, 0.0f, 1.0f };
  static GLfloat noShininess[] = { 0.0f };
  
  /* begin rendering OpenGL */
  
  /* turn off transparency and enable Z buffer as writable */
  glDisable (GL_BLEND);
  glDepthMask (GL_TRUE);
  View_transparencyIsOn = 0;
  
  /* turn on lighting */
  glEnable (GL_LIGHTING);
  View_lightIsOn = 1;
  
  /* turn off specular lighting */
  glMaterialfv (GL_FRONT_AND_BACK, GL_SPECULAR, noColor);
  glMaterialfv (GL_FRONT_AND_BACK, GL_SHININESS, noShininess);
  
  /* turn off texture mapping */
  glDisable (GL_TEXTURE_2D);
  
  /* set OpenGL viewport */
  {
    int widthDc, heightDc;

    AutoGL_GetViewRangeDc 
      (&widthDc, &heightDc);
    glViewport (0, 0, (GLsizei)widthDc, (GLsizei)heightDc);
  }

  /* reset projection matrix stack */
  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();
  
  SetProjection ();

  /* set background color */
  glClearColor (View_backgroundRed, 
		View_backgroundGreen, 
		View_backgroundBlue, 
		1.0f);

  /* clear color and depth buffers */
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  /* reset model view matrix stack */
  glMatrixMode (GL_MODELVIEW);
  glLoadIdentity ();

  SetViewingTransformation ();

  {
    double dirX, dirY, dirZ;

    /* set initial normal */
    AutoGL_GetViewDirection 
      (&dirX, &dirY, &dirZ);
    ModifyDirection 
      (&dirX, &dirY, &dirZ);
    glNormal3d (dirX, dirY, dirZ); 

    /* set initial color : white */
    glColor4f (1.0, 1.0, 1.0, 1.0); 
  }
}

void AutoGL_EndDrawingOpenGLWindow (void)
{
  /* end rendering OpenGL */

  /* flush drawing commands */
  glFlush ();
}

GLuint AutoGL_GetOpenGLCharBase (void)
{
  return View_charBase;
}

void AutoGL_TurnOnSpecular (void)
{
  static GLfloat specularColor[] = { 0.5f, 0.5f, 0.5f, 1.0f };
  static GLfloat specularShininess[] = { 50.0f };

  glMaterialfv (GL_FRONT_AND_BACK, GL_SPECULAR, specularColor);
  glMaterialfv (GL_FRONT_AND_BACK, GL_SHININESS, specularShininess);
}

void AutoGL_TurnOnTransparency (void)
{
  /* turn on transparency */
  glEnable (GL_BLEND);
  glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  
#if 0
  /* make Z buffer as read-only */
  glDepthMask (GL_FALSE);
#endif

  View_transparencyIsOn = 1;
}

void AutoGL_SetColor 
(double red, double green, double blue)
{
  if (View_transparencyIsOn) {
    glColor4f (red, green, blue, 0.5f);
  } else {
    glColor4f (red, green, blue, 1.0f);
  }
}

void AutoGL_SetTextureMap (int sizeLevel, const unsigned char image[])
{
  int i;
  int sizeDc;

  assert(0 <= sizeLevel);
  
  sizeDc = 1;
  for (i = 0; i < sizeLevel; i++) {
    sizeDc *= 2;
  }

  glEnable (GL_TEXTURE_2D);
  glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
  
  glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, 
		   GL_NEAREST_MIPMAP_NEAREST);
  gluBuild2DMipmaps (GL_TEXTURE_2D, 3, sizeDc, sizeDc, 
		     GL_RGB, GL_UNSIGNED_BYTE, 
		     image);
}

void AutoGL_DrawLine 
(double x0, double y0, double z0,
 double x1, double y1, double z1)
{
  TurnOffLighting ();

  /* draw a line segment */
  glBegin (GL_LINES);

  glVertex3d (x0, y0, z0);
  glVertex3d (x1, y1, z1);

  glEnd ();
}

void AutoGL_DrawTriangle 
(double x0, double y0, double z0,
 double x1, double y1, double z1,
 double x2, double y2, double z2)
{
  double nx, ny, nz;

  /* calculate the unit normal vector of the triangle */
  AutoGL_GetVectorProduct3D
    (&nx, &ny, &nz,
     x0 - x1, y0 - y1, z0 - z1,
     x1 - x2, y1 - y2, z1 - z2);
  AutoGL_NormalizeVector3D 
    (&nx, &ny, &nz,
     nx, ny, nz);

  TurnOnLighting ();

  /* draw two triangles (front side and back side) */

  glBegin (GL_TRIANGLES);

  glNormal3d (nx, ny, nz); 
  glVertex3d (x0, y0, z0);
  glVertex3d (x1, y1, z1);
  glVertex3d (x2, y2, z2);

  glNormal3d (-nx, -ny, -nz); 
  glVertex3d (x0, y0, z0);
  glVertex3d (x2, y2, z2);
  glVertex3d (x1, y1, z1);

  glEnd ();
}

void AutoGL_DrawColorInterpolatedTriangle
(double x0, double y0, double z0, double red0, double green0, double blue0,  
 double x1, double y1, double z1, double red1, double green1, double blue1,  
 double x2, double y2, double z2, double red2, double green2, double blue2)
{
  double nx, ny, nz;

  /* calculate the unit normal vector of the triangle */
  AutoGL_GetVectorProduct3D
    (&nx, &ny, &nz,
     x0 - x1, y0 - y1, z0 - z1,
     x1 - x2, y1 - y2, z1 - z2);
  AutoGL_NormalizeVector3D 
    (&nx, &ny, &nz,
     nx, ny, nz);

  TurnOnLighting ();

  /* draw two triangles (front side and back side) */

  glBegin (GL_TRIANGLES);

  glNormal3d (nx, ny, nz); 
  glColor3d (red0, green0, blue0);
  glVertex3d (x0, y0, z0);
  glColor3d (red1, green1, blue1);
  glVertex3d (x1, y1, z1);
  glColor3d (red2, green2, blue2);
  glVertex3d (x2, y2, z2);

  glNormal3d (-nx, -ny, -nz); 
  glColor3d (red0, green0, blue0);
  glVertex3d (x0, y0, z0);
  glColor3d (red2, green2, blue2);
  glVertex3d (x2, y2, z2);
  glColor3d (red1, green1, blue1);
  glVertex3d (x1, y1, z1);

  glEnd ();
}

void AutoGL_DrawNormalInterpolatedTriangle 
(double x0, double y0, double z0, double nx0, double ny0, double nz0,
 double x1, double y1, double z1, double nx1, double ny1, double nz1,
 double x2, double y2, double z2, double nx2, double ny2, double nz2)
{
  double nx, ny, nz;
  double nnx0, nny0, nnz0;
  double nnx1, nny1, nnz1;
  double nnx2, nny2, nnz2;

  /* calculate the unit normal vector of the triangle */
  AutoGL_GetVectorProduct3D
    (&nx, &ny, &nz,
     x0 - x1, y0 - y1, z0 - z1,
     x1 - x2, y1 - y2, z1 - z2);
  AutoGL_NormalizeVector3D 
    (&nx, &ny, &nz,
     nx, ny, nz);

  /* normalize the normal vector of each vertex */
  AutoGL_NormalizeVector3D 
    (&nnx0, &nny0, &nnz0,
     nx0, ny0, nz0);
  AutoGL_NormalizeVector3D 
    (&nnx1, &nny1, &nnz1,
     nx1, ny1, nz1);
  AutoGL_NormalizeVector3D 
    (&nnx2, &nny2, &nnz2,
     nx2, ny2, nz2);

  TurnOnLighting ();

  /* draw two triangles (front side and back side) */

  glBegin (GL_TRIANGLES);

  /* (nx, ny, nz) is the same direction as (nnx0, nny0, nnz0) */
  if (0.0 < AutoGL_GetScalarProduct3D (nx, ny, nz, 
				       nnx0, nny0, nnz0)) {
    glNormal3d (nnx0, nny0, nnz0); 
    glVertex3d (x0, y0, z0);
    glNormal3d (nnx1, nny1, nnz1); 
    glVertex3d (x1, y1, z1);
    glNormal3d (nnx2, nny2, nnz2); 
    glVertex3d (x2, y2, z2);
    
    glNormal3d (-nnx0, -nny0, -nnz0); 
    glVertex3d (x0, y0, z0);
    glNormal3d (-nnx2, -nny2, -nnz2); 
    glVertex3d (x2, y2, z2);
    glNormal3d (-nnx1, -nny1, -nnz1); 
    glVertex3d (x1, y1, z1);
  } else {
    glNormal3d (-nnx0, -nny0, -nnz0); 
    glVertex3d (x0, y0, z0);
    glNormal3d (-nnx1, -nny1, -nnz1); 
    glVertex3d (x1, y1, z1);
    glNormal3d (-nnx2, -nny2, -nnz2); 
    glVertex3d (x2, y2, z2);
    
    glNormal3d (nnx0, nny0, nnz0); 
    glVertex3d (x0, y0, z0);
    glNormal3d (nnx2, nny2, nnz2); 
    glVertex3d (x2, y2, z2);
    glNormal3d (nnx1, nny1, nnz1); 
    glVertex3d (x1, y1, z1);
  }

  glEnd ();
}

void AutoGL_DrawTexturedTriangle 
(double x0, double y0, double z0,
 double x1, double y1, double z1,
 double x2, double y2, double z2,
 double scaleFactor)
{
  double nx, ny, nz;
  double ux, uy, uz;
  double vx, vy, vz;
  double tx0, ty0;
  double tx1, ty1;
  double tx2, ty2;

  /* calculate the unit normal vector of the triangle */
  AutoGL_GetVectorProduct3D
    (&nx, &ny, &nz,
     x0 - x1, y0 - y1, z0 - z1,
     x1 - x2, y1 - y2, z1 - z2);
  AutoGL_NormalizeVector3D 
    (&nx, &ny, &nz,
     nx, ny, nz);

  AutoGL_GetAnyPerpendicularDirection3D 
    (&ux, &uy, &uz,
     &vx, &vy, &vz,
     nx, ny, nz);
  
  tx0 = AutoGL_GetScalarProduct3D (x0, y0, z0, 
				   ux, uy, uz) / scaleFactor;
  ty0 = AutoGL_GetScalarProduct3D (x0, y0, z0, 
				   vx, vy, vz) / scaleFactor;

  tx1 = AutoGL_GetScalarProduct3D (x1, y1, z1, 
				   ux, uy, uz) / scaleFactor;
  ty1 = AutoGL_GetScalarProduct3D (x1, y1, z1, 
				   vx, vy, vz) / scaleFactor;

  tx2 = AutoGL_GetScalarProduct3D (x2, y2, z2, 
				   ux, uy, uz) / scaleFactor;
  ty2 = AutoGL_GetScalarProduct3D (x2, y2, z2, 
				   vx, vy, vz) / scaleFactor;

  TurnOnLighting ();

  /* draw two triangles (front side and back side) */

  glBegin (GL_TRIANGLES);

  glNormal3d (nx, ny, nz); 
  glTexCoord2d (tx0, ty0); 
  glVertex3d (x0, y0, z0);
  glTexCoord2d (tx1, ty1); 
  glVertex3d (x1, y1, z1);
  glTexCoord2d (tx2, ty2); 
  glVertex3d (x2, y2, z2);

  glNormal3d (-nx, -ny, -nz); 
  glTexCoord2d (tx0, ty0); 
  glVertex3d (x0, y0, z0);
  glTexCoord2d (tx2, ty2); 
  glVertex3d (x2, y2, z2);
  glTexCoord2d (tx1, ty1); 
  glVertex3d (x1, y1, z1);

  glEnd ();
}

void AutoGL_DrawQuadrangle 
(double x0, double y0, double z0,
 double x1, double y1, double z1,
 double x2, double y2, double z2,
 double x3, double y3, double z3)
{
  AutoGL_DrawTriangle (x0, y0, z0,
		       x1, y1, z1,
		       x2, y2, z2);
  AutoGL_DrawTriangle (x2, y2, z2,
		       x3, y3, z3,
		       x0, y0, z0);
}

void AutoGL_DrawString 
(double x, double y, double z,
 const char *str)
{
  TurnOffLighting ();

  /* draw character string at the point */

  glRasterPos3d (x, y, z);

  glPushAttrib (GL_LIST_BIT);
  glListBase (View_charBase);
  glCallLists (strlen (str), GL_UNSIGNED_BYTE, str);
  glPopAttrib ();
}

void AutoGL_DrawImage 
(double x, double y, double z,
 int widthDc, int heightDc, const unsigned char image[])
{
  TurnOffLighting ();

  /* draw image of size (<widthDc>, <heightDc>) at the point */

  glRasterPos3d (x, y, z);

  glDrawPixels (widthDc, heightDc, GL_RGB, GL_UNSIGNED_BYTE, 
		(GLubyte *)image);
}

void AutoGL_GetViewImage
(unsigned char image_OUT[])
{
  int widthDc, heightDc;

  AutoGL_GetViewRangeDc 
    (&widthDc, &heightDc);

  /* read image data of the view window into <image_OUT> */

  glReadPixels (0, 0, widthDc, heightDc, GL_RGB, GL_UNSIGNED_BYTE, 
		(GLubyte *)image_OUT);
}

void AutoGL_OpenDisplayList (void)
{
  /* open a new display list of id <View_DisplayListId> */
  glNewList (View_DisplayListId, GL_COMPILE);
}

void AutoGL_CloseDisplayList (void)
{
  /* close the display list */
  glEndList ();
}

void AutoGL_DrawDisplayList (void)
{
  TurnOnLighting ();

  /* draw the display list of id <View_DisplayListId> */
  glCallList (View_DisplayListId);
}

void AutoGL_StartSelection (int x, int y, int range)
{
  int widthDc, heightDc;
  GLint viewport[4];

  AutoGL_GetViewRangeDc 
    (&widthDc, &heightDc);

  /* set OpenGL selection buffer */
  glSelectBuffer (MAX_SELECT_BUFFER_SIZE, View_selectBuffer);

  glGetIntegerv (GL_VIEWPORT, 
		 viewport);

  glMatrixMode (GL_PROJECTION);
  glPushMatrix ();

  /* switch mode to OpenGL selection */
  (void)glRenderMode (GL_SELECT);

  /* set a new view volume around the mouse cursor (x, y) */
  glLoadIdentity ();
  gluPickMatrix 
    ((GLdouble)(widthDc / 2 + x), (GLdouble)(heightDc / 2 + y),
     (GLdouble)range, (GLdouble)range, 
     viewport);

  SetProjection ();

  /* reset model view matrix stack */
  glMatrixMode (GL_MODELVIEW);
  glLoadIdentity ();

  SetViewingTransformation ();

  glInitNames ();
  glPushName (100);
}

void AutoGL_SetSelectionId (int id)
{
  int name = id;

  /* set the current name (object ID) of OpenGL selection */
  glLoadName (name);
}

void AutoGL_EndSelection (void)
{
  glFlush ();

  /* switch mode back to OpenGL rendering */
  /* get the number of hits */
  View_nHits = glRenderMode (GL_RENDER);

  glMatrixMode (GL_PROJECTION);
  glPopMatrix ();
  
  glMatrixMode (GL_MODELVIEW);
}

int AutoGL_GetSelectedId (void)
{
  int result;
  int iHit;
  int count;
  GLuint minZ;

  result = -1;
  minZ = 0;
  count = 0;
  for (iHit = 0; iHit < View_nHits; iHit++) {
    int nNames;
    GLuint name;
    GLuint z0, z1;
    
    nNames = View_selectBuffer[count++];
    assert(nNames == 1);
    z0 = View_selectBuffer[count++];
    z1 = View_selectBuffer[count++];
    name = View_selectBuffer[count++];

    if (result == -1
	|| z0 < minZ) {
      minZ = z0;
      result = name;
    }
  }

  result = GatherSelectedId (result, minZ);

  return result;
}



