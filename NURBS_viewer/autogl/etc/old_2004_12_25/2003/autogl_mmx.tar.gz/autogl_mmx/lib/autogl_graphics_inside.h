/* header file for autogl_graphics.c */

#ifndef __AUTOGL_GRAPHICS_INSIDE__
#define __AUTOGL_GRAPHICS_INSIDE__



void AutoGL_SetViewRangeDc (int widthDc, int heightDc);

void AutoGL_SetPointingDeviceEvent 
(int event,   /* AUTOGL_EVENT_ */
 int dcX, int dcY, int dcZ);

void AutoGL_SetKeyEvent (int keyChar);



#endif  /* __AUTOGL_GRAPHICS_INSIDE__ */



