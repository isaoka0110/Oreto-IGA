/* autogl_graphics.c : graphics */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "autogl_math.h"
#include "autogl_graphics.h"
#include "autogl_graphics_inside.h"



/* Module Variables */

static double View_size = 1.0;
static double View_centerX = 0.0;
static double View_centerY = 0.0;
static double View_centerZ = 0.0;
static double View_directionX = 0.0;
static double View_directionY = 0.0;
static double View_directionZ = 1.0;
static double View_upVectorX = 0.0;
static double View_upVectorY = 1.0;
static double View_upVectorZ = 0.0;

static int View_widthDc = 100;
static int View_heightDc = 100;

static int View_eventType;  /* AUTOGL_EVENT_ */

static int View_pointingDeviceDcX;
static int View_pointingDeviceDcY;
static int View_pointingDeviceDcZ;

static int View_keyChar;

static int View_perspectiveViewFlag = 0;



void AutoGL_SetViewSize (double size)
{
  View_size = size;
}

void AutoGL_SetViewCenter (double x, double y, double z)
{
  View_centerX = x;
  View_centerY = y;
  View_centerZ = z;
}

void AutoGL_SetViewDirection (double x, double y, double z)
{
  AutoGL_NormalizeVector3D 
    (&View_directionX, &View_directionY, &View_directionZ,
     x, y, z);
}

void AutoGL_SetViewUpVector (double x, double y, double z)
{
  AutoGL_NormalizeVector3D 
    (&View_upVectorX, &View_upVectorY, &View_upVectorZ,
     x, y, z);
}

void AutoGL_SetPerspectiveViewFlag (int flag)
{
  View_perspectiveViewFlag = flag;
}

void AutoGL_SetViewRangeDc (int widthDc, int heightDc)
{
  View_widthDc = (widthDc <= 0) ? 1 : widthDc;
  View_heightDc = (heightDc <= 0) ? 1 : heightDc;
}

double AutoGL_GetViewSize (void)
{
  return View_size;
}

void AutoGL_GetViewCenter 
(double *x_OUT, double *y_OUT, double *z_OUT)
{
  *x_OUT = View_centerX;
  *y_OUT = View_centerY;
  *z_OUT = View_centerZ;
}

void AutoGL_GetViewDirection 
(double *x_OUT, double *y_OUT, double *z_OUT)
{
  *x_OUT = View_directionX;
  *y_OUT = View_directionY;
  *z_OUT = View_directionZ;
}

void AutoGL_GetViewUpVector 
(double *x_OUT, double *y_OUT, double *z_OUT)
{
  *x_OUT = View_upVectorX; 
  *y_OUT = View_upVectorY;
  *z_OUT = View_upVectorZ;
}

int AutoGL_GetPerspectiveViewFlag ()
{
  return View_perspectiveViewFlag;
}

void AutoGL_GetViewRangeDc 
(int *widthDc_OUT, int *heightDc_OUT)
{
  *widthDc_OUT = View_widthDc;
  *heightDc_OUT = View_heightDc;
}

int AutoGL_GetViewSizeDc (void)
{
  return (View_widthDc < View_heightDc) ?
    View_widthDc / 2 : View_heightDc / 2;
}

void AutoGL_GetVcOfDc 
(double *vcX_OUT, double *vcY_OUT, double *vcZ_OUT,
 int dcX, int dcY, int dcZ)
{
  double size = AutoGL_GetViewSize ();
  int sizeDc = AutoGL_GetViewSizeDc ();

  *vcX_OUT = size * dcX / sizeDc;
  *vcY_OUT = size * dcY / sizeDc;
  *vcZ_OUT = size * dcZ / sizeDc;
}

void AutoGL_GetPositionOfVc 
(double *x_OUT, double *y_OUT, double *z_OUT,
 double vcX, double vcY, double vcZ)
{
  double centerX, centerY, centerZ;
  double zAxisX, zAxisY, zAxisZ;
  double upX, upY, upZ;
  double xAxisX, xAxisY, xAxisZ;
  double yAxisX, yAxisY, yAxisZ;

  AutoGL_GetViewCenter (&centerX, &centerY, &centerZ);
  AutoGL_GetViewDirection (&zAxisX, &zAxisY, &zAxisZ);
  AutoGL_GetViewUpVector (&upX, &upY, &upZ);

  AutoGL_GetVectorProduct3D (&xAxisX, &xAxisY, &xAxisZ,
			     upX, upY, upZ,
			     zAxisX, zAxisY, zAxisZ);
  AutoGL_NormalizeVector3D (&xAxisX, &xAxisY, &xAxisZ,
			    xAxisX, xAxisY, xAxisZ);
  
  AutoGL_GetVectorProduct3D (&yAxisX, &yAxisY, &yAxisZ,
			     zAxisX, zAxisY, zAxisZ, 
			     xAxisX, xAxisY, xAxisZ);
  AutoGL_NormalizeVector3D (&yAxisX, &yAxisY, &yAxisZ,
			    yAxisX, yAxisY, yAxisZ);
  
  AutoGL_AddVector3D (x_OUT, y_OUT, z_OUT,
		      centerX, centerY, centerZ,
		      xAxisX * vcX + yAxisX * vcY + zAxisX * vcZ,
		      xAxisY * vcX + yAxisY * vcY + zAxisY * vcZ,
		      xAxisZ * vcX + yAxisZ * vcY + zAxisZ * vcZ);
}

void AutoGL_GetPositionOfDc 
(double *x_OUT, double *y_OUT, double *z_OUT,
 int dcX, int dcY, int dcZ)
{
  double vcX, vcY, vcZ;

  AutoGL_GetVcOfDc (&vcX, &vcY, &vcZ,
		    dcX, dcY, dcZ);
  AutoGL_GetPositionOfVc (x_OUT, y_OUT, z_OUT,
			  vcX, vcY, vcZ);
}

void AutoGL_SetPointingDeviceEvent 
(int event,   /* AUTOGL_EVENT_ */
 int dcX, int dcY, int dcZ)
{
  View_eventType = event;
  View_pointingDeviceDcX = dcX;
  View_pointingDeviceDcY = dcY;
  View_pointingDeviceDcZ = dcZ;
}

void AutoGL_SetKeyEvent 
(int keyChar)
{
  View_eventType = AUTOGL_EVENT_KEY;
  View_keyChar = keyChar;
}

int AutoGL_GetViewEvent (void)  /* AUTOGL_EVENT_ */
{
  return View_eventType;
}

void AutoGL_GetPointingDevicePositionDc 
(int *dcX_OUT, int *dcY_OUT, int *dcZ_OUT)
{
  *dcX_OUT = View_pointingDeviceDcX;
  *dcY_OUT = View_pointingDeviceDcY;
  *dcZ_OUT = View_pointingDeviceDcZ;
}

int AutoGL_GetKeyChar (void)
{
  return View_keyChar;
}



