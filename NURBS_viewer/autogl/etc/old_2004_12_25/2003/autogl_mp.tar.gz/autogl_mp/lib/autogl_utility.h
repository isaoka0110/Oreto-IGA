/* AutoGL */

#ifndef __AUTOGL_UTILITY__
#define __AUTOGL_UTILITY__

/* $B%f!<%F%#%j%F%#(B */



/* $B%3%^%s%I%i%$%s=hM}$H%9%/%j%W%F%#%s%0(B */

/* $B%3%^%s%I%i%$%s=hM}$H%9%/%j%W%F%#%s%05!G=$r%Q%M%k$K=`Hw$9$k!#(B */
void AutoGL_SetPanelForInterpreter (void);



/* $BIA2h%W%j%_%F%#%V(B */

/* $B%3%s%?(B-$B$NCM$KBP1~$9$k?'$rF@$k!#(B */
void AutoGL_GetContourColor 
(double *red_OUT, double *green_OUT, double *blue_OUT,
 double grade);
/* red_OUT, green_OUT, blue_OUT : $B@V!"NP!"@D$K$D$$$F!"$=$l$>$l(B0.0 - 1.0$B$N%l%s%8$N6/EY!#(B */
/* grade : 0.0 - 1.0$B$K5,3J2=$5$l$?CM!#(B */

/* $B;03Q7A$r%3%s%?(B-$B$GEI$jDY$9!#(B */
void AutoGL_DrawContourTriangle 
(double x0, double y0, double z0, double grade0,  
 double x1, double y1, double z1, double grade1,  
 double x2, double y2, double z2, double grade2); 
/* (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) : $B;0E@$N@$3&:BI8(B */
/* grade0, grade1, grade2 : $B;0E@$N%9%+%i!<CM!J(B0.0 - 1.0$B$K5,3J2=!K(B */

/* $B2hLL1&$KLL%3%s%?(B-$B$G$N?'$HCM$H$NBP1~I=$r%P!<I=<($9$k!#(B */
void AutoGL_DrawContourMap 
(int sizeDc,
 double minRange, double maxRange);
/* sizeDc : $B2hLL$K@j$a$k%G%P%$%9:BI87O$G$NI}(B */
/* minRange, maxRange : $B%9%+%i!<CM$N:GBg:G>.(B */

/* $B2hLL1&$K@~%3%s%?(B-$B$G$N?'$HCM$H$NBP1~I=$r%P!<I=<($9$k!#(B */
void AutoGL_DrawLineContourMap 
(int sizeDc,
 double minRange, double maxRange,
 int nGrades);
/* sizeDc : $B2hLL$K@j$a$k%G%P%$%9:BI87O$G$NI}(B */
/* minRange, maxRange : $B%9%+%i!<CM$N:GBg:G>.(B */
/* nGrades : $B@~%3%s%?(B-$B$NK\?t(B (-1) */



/* $B2D;k2=(B */

/* $B#1$D$NO;LLBN$r#6$D$N;MLLBN$KJ,3d$9$k$5$$$ND:E@BP1~I=(B */
extern int AutoGL_HexToTetraMap[6][4];

/* $B;03Q7A$+$iEy9b@~!JEyCM@~!K%G!<%?$r7W;;$9$k!#(B */
int AutoGL_GetIsoline 
(int vertexIds0_OUT[2],
 int vertexIds1_OUT[2],
 double ratios_OUT[2],
 double levelValue, 
 double triValues[3]);
/* vertexIds0_OUT, vertexIds0_OUT : $BEy9b@~$N;03Q7A$K$*$1$kD:E@HV9f(B */
/* ratios_OUT : $B>e5-#2D:E@4V$NJd4VHfN((B */
/* levelValue : $BEy9b@~$N%9%+%i!<CM(B */
/* triValues : $B;03Q7A$N3FD:E@$N%9%+%i!<CM(B */

/* $B;03Q7A$+$iEy9b@~!JEyCM@~!K$ND:E@$r7W;;$9$k!#(B */
void AutoGL_GetIsolineVertex 
(double points_OUT[2][3],
 double triPoints[3][3], 
 int vertexIds0[2],
 int vertexIds1[2],
 double ratios[2]);
/* points_OUT : $BEy9b@~$ND:E@:BI8(B */
/* triPoints : $B;03Q7A$N3FD:E@$N:BI8(B */
/* nVertexs : $BEy9b@~$ND:E@?t(B */
/* vertexIds0, vertexIds0 : $BEy9b@~$N;03Q7A$K$*$1$kD:E@HV9f(B */
/* ratios : $B>e5-#2D:E@4V$NJd4VHfN((B */

/* $B;03Q7A$NEy9b@~!JEyCM@~!K$rIA2h$9$k!#(B */
void AutoGL_DrawTriangleIsoline 
(double levelValue,
 double triPoints[3][3],
 double triValues[3]);
/* levelValue : $BEy9b@~$N%9%+%i!<CM(B */
/* triPoints : $B;03Q7A$N3FD:E@$N:BI8(B */
/* triValues : $B;03Q7A$N3FD:E@$N%9%+%i!<CM(B */

/* $B;MLLBN$+$iEy9bLL!JEyCMLL!K%G!<%?$r7W;;$9$k!#(B */
int AutoGL_GetIsosurface 
(int *nVertexs_OUT,
 int vertexIds0_OUT[4],
 int vertexIds1_OUT[4],
 double ratios_OUT[4],
 double levelValue, 
 double tetraValues[4]);
/* nVertexs_OUT : $BEyCMLL$ND:E@?t(B */
/* vertexIds0_OUT, vertexIds0_OUT : $BEyCMLL$N;MLLBN$K$*$1$kD:E@HV9f(B */
/* ratios_OUT : $B>e5-#2D:E@4V$NJd4VHfN((B */
/* levelValue : $BEy9b@~$N%9%+%i!<CM(B */
/* tetraValues : $B;MLLBN$N3FD:E@$N%9%+%i!<CM(B */

/* $B;MLLBN$+$iEy9bLL!JEyCMLL!K$ND:E@$r7W;;$9$k!#(B */
void AutoGL_GetIsosurfaceVertex 
(double points_OUT[4][3],
 double tetraPoints[4][3], 
 int nVertexs, 
 int vertexIds0[4],
 int vertexIds1[4],
 double ratios[4]);
/* points_OUT : $BEyCMLL$ND:E@:BI8(B */
/* tetraPoints : $B;MLLBN$N3FD:E@$N:BI8(B */
/* nVertexs : $BEyCMLL$ND:E@?t(B */
/* vertexIds0, vertexIds0 : $BEyCMLL$N;MLLBN$K$*$1$kD:E@HV9f(B */
/* ratios : $B>e5-#2D:E@4V$NJd4VHfN((B */

/* $B;MLLBN$NEy9bLL!JEyCMLL!K$rIA2h$9$k!#(B */
void AutoGL_DrawTetrahedronIsosurface 
(double levelValue,
 double tetraPoints[4][3],
 double tetraValues[4]);
/* levelValue : $BEy9b@~$N%9%+%i!<CM(B */
/* tetraPoints : $B;MLLBN$N3FD:E@$N:BI8(B */
/* tetraValues : $B;MLLBN$N3FD:E@$N%9%+%i!<CM(B */

/* $B;MLLBN$HJ?LL$H$N8r:9CGLL$NLL%3%s%?(B-$B$rIA2h$9$k!#(B */
void AutoGL_DrawTetrahedronSectionContour 
(double a, double b, double c, double d,
 double tetraPoints[4][3],
 double tetraGrades[4]);
/* a, b, c, d : $BCGLL$NJ}Dx<0(Bax+by+cz+d=0$B$N78?t(B */
/* tetraPoints : $B;MLLBN$N3FD:E@$N:BI8(B */
/* tetraGrades : $B;MLLBN$N3FD:E@$N%9%+%i!<CM$r(B0.0 - 1.0$B$K@55,2=$7$?$b$N(B */



/* $B%U%!%$%kF~=PNO(B */

/* PPM$B%U%!%$%k$K%S%e!<$N%$%a!<%8$rJ]B8$9$k!#(B*/
void AutoGL_SaveViewImageToPPMFile (const char *fileName);

/* PPM$B%U%!%$%k$+$i%$%a!<%8$rFI$_=P$9!#(B*/
void AutoGL_ReadImageFromPPMFile 
(const char *fileName,
 int *widthDcPtr_OUT, int *heightDcPtr_OUT, unsigned char **imagePtr_OUT);

/* $B2hLL%;!<%V5!G=$r%Q%M%k$K=`Hw$9$k!#(B*/
void AutoGL_SetPanelForSave (void);



#endif  /* __AUTOGL_UTILITY__ */



