/* header file for autogl_com.c */

#ifndef __AUTOGL_COM_INSIDE__
#define __AUTOGL_COM_INSIDE__



void AutoGL_InitializeAutoNOSim (int *argc, char ***argv);
void AutoGL_Synchronize ();
int AutoGL_IsSynchronized ();
void AutoGL_SendRedrawEvent ();
void AutoGL_SendCallbackEvent (AutoGL_Property *property);
void AutoGL_SendIdleEvent ();
void AutoGL_SendMouseEvent ();
void AutoGL_SendKeyEvent ();



#endif  /* __AUTOGL_COM_INSIDE__ */



