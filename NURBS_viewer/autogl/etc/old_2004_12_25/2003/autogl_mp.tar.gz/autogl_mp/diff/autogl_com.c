/* autogl_com.c : communication using AutoNOSim */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include <autonosim.h>

#include "autogl_math.h"
#include "autogl_os.h"
#include "autogl_uims.h"
#include "autogl_graphics.h"
#include "autogl_cui.h"
#include "autogl_gui.h"

#include "autogl_uims_inside.h"
#include "autogl_com_inside.h"
#include "autogl_graphics_inside.h"
#include "autogl_gui_inside.h"



#if 0
#define MSG
#endif



/* Module Variables */

#define AUTOGL_COM_COMMAND_REDRAW 0
#define AUTOGL_COM_COMMAND_CALLBACK 1
#define AUTOGL_COM_COMMAND_IDLE 2
#define AUTOGL_COM_COMMAND_MOUSE 3
#define AUTOGL_COM_COMMAND_KEY 4

static int NTasks;
static int MyTaskId;
static int IsSynchronized;



void AutoGL_InitializeAutoNOSim (int *argc, char ***argv)
{
  AutoNOSim_Initialize (argc, argv);
  
  NTasks = AutoNOSim_NTasks ();
  MyTaskId = AutoNOSim_MyTaskId ();
}

static void SendReceivePropertyArguments ()
{
  int nPropertys;
  int iProperty;
  
  nPropertys = AutoGL_GetNPropertys ();
  for (iProperty = 0; iProperty < nPropertys; iProperty++) {
    AutoGL_Property *property = AutoGL_GetProperty (iProperty);
    
    switch (property->type) {
    case AUTOGL_PROPERTY_GROUP:
    case AUTOGL_PROPERTY_COMMENT:
    case AUTOGL_PROPERTY_CALLBACK:
      break;
    case AUTOGL_PROPERTY_BOOLEAN:
      AutoNOSim_Integer (property->booleanValue);
      break;
    case AUTOGL_PROPERTY_STRING:
      AutoNOSim_String (property->stringValue, property->stringLength);
      break;
    case AUTOGL_PROPERTY_INTEGER:
      AutoNOSim_Integer (property->integerValue);
      break;
    case AUTOGL_PROPERTY_REAL:
      AutoNOSim_Real (property->realValue);
      break;
    default:
      assert(0);
      break;
    }
  }
}



/* REDRAW function */

static double REDRAW_Size;
static double REDRAW_CenterX;
static double REDRAW_CenterY;
static double REDRAW_CenterZ;
static double REDRAW_DirectionX;
static double REDRAW_DirectionY;
static double REDRAW_DirectionZ;
static double REDRAW_UpVectorX;
static double REDRAW_UpVectorY;
static double REDRAW_UpVectorZ;

static void REDRAW_Arguments ()
{
  AutoNOSim_Real (&REDRAW_Size);
  AutoNOSim_Real (&REDRAW_CenterX);
  AutoNOSim_Real (&REDRAW_CenterY);
  AutoNOSim_Real (&REDRAW_CenterZ);
  AutoNOSim_Real (&REDRAW_DirectionX);
  AutoNOSim_Real (&REDRAW_DirectionY);
  AutoNOSim_Real (&REDRAW_DirectionZ);
  AutoNOSim_Real (&REDRAW_UpVectorX);
  AutoNOSim_Real (&REDRAW_UpVectorY);
  AutoNOSim_Real (&REDRAW_UpVectorZ);
}

static void REDRAW_Body ()
{
  assert(MyTaskId != AUTONOSIM_MASTER_TASK_ID);

  AutoGL_SetViewSize (REDRAW_Size);
  AutoGL_SetViewCenter (REDRAW_CenterX, 
			REDRAW_CenterY, 
			REDRAW_CenterZ);
  AutoGL_SetViewDirection (REDRAW_DirectionX, 
			   REDRAW_DirectionY, 
			   REDRAW_DirectionZ);
  AutoGL_SetViewUpVector (REDRAW_UpVectorX, 
			  REDRAW_UpVectorY, 
			  REDRAW_UpVectorZ);

#ifdef MSG
  fprintf (stderr, " [taskId %d] redraw event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  AutoGL_UpdateView ();
}

void AutoGL_SendRedrawEvent ()
{
  int iTask;
  int commandId;

  if (!AutoGL_IsSynchronized ()) return;

  assert(MyTaskId == AUTONOSIM_MASTER_TASK_ID);

  AutoNOSim_Clear (AUTONOSIM_PACKING);

  commandId = AUTOGL_COM_COMMAND_REDRAW;
  AutoNOSim_Integer (&commandId);

  REDRAW_Size = AutoGL_GetViewSize ();
  AutoGL_GetViewCenter (&REDRAW_CenterX, 
			&REDRAW_CenterY, 
			&REDRAW_CenterZ);
  AutoGL_GetViewDirection (&REDRAW_DirectionX, 
			   &REDRAW_DirectionY, 
			   &REDRAW_DirectionZ);
  AutoGL_GetViewUpVector (&REDRAW_UpVectorX, 
			  &REDRAW_UpVectorY, 
			  &REDRAW_UpVectorZ);
  REDRAW_Arguments ();

  for (iTask = 0; iTask < NTasks; iTask++) {
    if (iTask != AUTONOSIM_MASTER_TASK_ID) {
      AutoNOSim_SendTo (iTask);
    }
  }

#ifdef MSG
  fprintf (stderr, " [taskId %d] redraw event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  AutoGL_UpdateView ();
}



/* CALLBACK function */

static int CALLBACK_PropertyId;

static void CALLBACK_Arguments ()
{
  AutoNOSim_Integer (&CALLBACK_PropertyId);

  SendReceivePropertyArguments ();
}

static void CALLBACK_Body ()
{
  AutoGL_Property *property;
  
  assert(MyTaskId != AUTONOSIM_MASTER_TASK_ID);

  property = AutoGL_GetProperty (CALLBACK_PropertyId);

#ifdef MSG
  fprintf (stderr, " [taskId %d] callback event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*property->callback) ();
}

static int GetPropertyId (AutoGL_Property *property)
{
  int nPropertys;
  int iProperty;
  
  nPropertys = AutoGL_GetNPropertys ();
  for (iProperty = 0; iProperty < nPropertys; iProperty++) {
    if (property == AutoGL_GetProperty (iProperty)) {
      return iProperty;
    }
  }
  
  assert(0);
  return -1;
}

void AutoGL_SendCallbackEvent (AutoGL_Property *property)
{
  int iTask;
  int commandId;

  if (!AutoGL_IsSynchronized ()) return;

  assert(MyTaskId == AUTONOSIM_MASTER_TASK_ID);
  assert(property->type == AUTOGL_PROPERTY_CALLBACK);

  AutoNOSim_Clear (AUTONOSIM_PACKING);

  commandId = AUTOGL_COM_COMMAND_CALLBACK;
  AutoNOSim_Integer (&commandId);

  CALLBACK_PropertyId = GetPropertyId (property);
  CALLBACK_Arguments ();

  for (iTask = 0; iTask < NTasks; iTask++) {
    if (iTask != AUTONOSIM_MASTER_TASK_ID) {
      AutoNOSim_SendTo (iTask);
    }
  }

#ifdef MSG
  fprintf (stderr, " [taskId %d] callback event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*property->callback) ();
}



/* IDLE function */

static void IDLE_Arguments ()
{
}

static void IDLE_Body ()
{
  AutoGL_CallbackType callback = AutoGL_GetIdleEventCallback ();

  assert(MyTaskId != AUTONOSIM_MASTER_TASK_ID);
  assert(callback != NULL);

#ifdef MSG
  fprintf (stderr, " [taskId %d] idle event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();
  
  (*callback) ();
}

void AutoGL_SendIdleEvent ()
{
  AutoGL_CallbackType callback = AutoGL_GetIdleEventCallback ();
  int iTask;
  int commandId;

  if (!AutoGL_IsSynchronized ()) return;

  assert(MyTaskId == AUTONOSIM_MASTER_TASK_ID);
  assert(callback != NULL);

  AutoNOSim_Clear (AUTONOSIM_PACKING);

  commandId = AUTOGL_COM_COMMAND_IDLE;
  AutoNOSim_Integer (&commandId);

  for (iTask = 0; iTask < NTasks; iTask++) {
    if (iTask != AUTONOSIM_MASTER_TASK_ID) {
      AutoNOSim_SendTo (iTask);
    }
  }

#ifdef MSG
  fprintf (stderr, " [taskId %d] idle event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*callback) ();
}



/* MOUSE function */

static int MOUSE_event;
static int MOUSE_dcX;
static int MOUSE_dcY;
static int MOUSE_dcZ;

static void MOUSE_Arguments ()
{
  AutoNOSim_Integer (&MOUSE_event);
  AutoNOSim_Integer (&MOUSE_dcX);
  AutoNOSim_Integer (&MOUSE_dcY);
  AutoNOSim_Integer (&MOUSE_dcZ);

  SendReceivePropertyArguments ();
}

static void MOUSE_Body ()
{
  AutoGL_CallbackType callback = AutoGL_GetViewEventCallback ();

  assert(MyTaskId != AUTONOSIM_MASTER_TASK_ID);
  assert(callback != NULL);

  AutoGL_SetPointingDeviceEvent 
    (MOUSE_event, 
     MOUSE_dcX, MOUSE_dcY, MOUSE_dcZ);

#ifdef MSG
  fprintf (stderr, " [taskId %d] mouse event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*callback) ();
}

void AutoGL_SendMouseEvent ()
{
  AutoGL_CallbackType callback = AutoGL_GetViewEventCallback ();
  int iTask;
  int commandId;

  if (!AutoGL_IsSynchronized ()) return;

  assert(MyTaskId == AUTONOSIM_MASTER_TASK_ID);
  assert(callback != NULL);

  AutoNOSim_Clear (AUTONOSIM_PACKING);

  commandId = AUTOGL_COM_COMMAND_MOUSE;
  AutoNOSim_Integer (&commandId);

  MOUSE_event = AutoGL_GetViewEvent (); 
  AutoGL_GetPointingDevicePositionDc 
    (&MOUSE_dcX, &MOUSE_dcY, &MOUSE_dcZ);
  MOUSE_Arguments ();

  for (iTask = 0; iTask < NTasks; iTask++) {
    if (iTask != AUTONOSIM_MASTER_TASK_ID) {
      AutoNOSim_SendTo (iTask);
    }
  }

#ifdef MSG
  fprintf (stderr, " [taskId %d] mouse event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*callback) ();
}



/* KEY function */

static int KEY_keyChar;

static void KEY_Arguments ()
{
  AutoNOSim_Integer (&KEY_keyChar);

  SendReceivePropertyArguments ();
}

static void KEY_Body ()
{
  AutoGL_CallbackType callback = AutoGL_GetViewEventCallback ();

  assert(MyTaskId != AUTONOSIM_MASTER_TASK_ID);
  assert(callback != NULL);

  AutoGL_SetKeyEvent (KEY_keyChar);

#ifdef MSG
  fprintf (stderr, " [taskId %d] key event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*callback) ();
}

void AutoGL_SendKeyEvent ()
{
  AutoGL_CallbackType callback = AutoGL_GetViewEventCallback ();
  int iTask;
  int commandId;

  if (!AutoGL_IsSynchronized ()) return;

  assert(MyTaskId == AUTONOSIM_MASTER_TASK_ID);
  assert(callback != NULL);

  AutoNOSim_Clear (AUTONOSIM_PACKING);

  commandId = AUTOGL_COM_COMMAND_KEY;
  AutoNOSim_Integer (&commandId);

  KEY_keyChar = AutoGL_GetKeyChar (); 
  KEY_Arguments ();

  for (iTask = 0; iTask < NTasks; iTask++) {
    if (iTask != AUTONOSIM_MASTER_TASK_ID) {
      AutoNOSim_SendTo (iTask);
    }
  }

#ifdef MSG
  fprintf (stderr, " [taskId %d] key event \n",
	   MyTaskId);
#endif

  AutoNOSim_Barrier ();

  (*callback) ();
}



void AutoGL_Synchronize ()
{
  IsSynchronized = 1;

  fprintf (stderr, 
	   " [taskId %d] synchronize \n",
	   MyTaskId);
  
  if (MyTaskId == AUTONOSIM_MASTER_TASK_ID) return;

  for (;;) {
    int commandId;

    AutoNOSim_ReceiveFrom (AUTONOSIM_MASTER_TASK_ID);
    AutoNOSim_Clear (AUTONOSIM_UNPACKING);

    AutoNOSim_Integer (&commandId);

    switch (commandId) {
    case AUTOGL_COM_COMMAND_REDRAW:
      REDRAW_Arguments ();
      REDRAW_Body ();
      break;
    case AUTOGL_COM_COMMAND_CALLBACK:
      CALLBACK_Arguments ();
      CALLBACK_Body ();
      break;
    case AUTOGL_COM_COMMAND_IDLE:
      IDLE_Arguments ();
      IDLE_Body ();
      break;
    case AUTOGL_COM_COMMAND_MOUSE:
      MOUSE_Arguments ();
      MOUSE_Body ();
      break;
    case AUTOGL_COM_COMMAND_KEY:
      KEY_Arguments ();
      KEY_Body ();
      break;
    default:
      assert(0);
      break;
    }
  }
}

int AutoGL_IsSynchronized ()
{
  return IsSynchronized;
}

