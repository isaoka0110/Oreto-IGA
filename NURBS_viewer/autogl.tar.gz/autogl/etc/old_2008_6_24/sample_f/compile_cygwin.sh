g77 -o hello hello.f -L../lib -lautoglf -lglu32 -lopengl32 -luser32 -lgdi32
