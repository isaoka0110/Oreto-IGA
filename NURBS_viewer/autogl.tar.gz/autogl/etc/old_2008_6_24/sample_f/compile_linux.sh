g77 -o hello hello.f -L../lib -lautoglf -lgtkgl -lGLU -lGL `gtk-config --libs`
